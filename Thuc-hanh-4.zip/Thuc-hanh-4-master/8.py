s=input(' Nhap chuoi: ')
print(s)