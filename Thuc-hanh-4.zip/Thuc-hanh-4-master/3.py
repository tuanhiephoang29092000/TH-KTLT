s=input(" Nhap chuoi: ")
for ch in s.upper():
    print(ch)
