ds=input('nhap chuoi:').split()
ds.sort()
for ch in ds:
    print(ch)





