ds=input('nhap chuoi:').split()
x=ds[0:2]
ds.remove('123')
print(ds)
