ds=input('nhap chuoi:').split()
x=ds[0:-1]
ds.append('abc')
for ch in ds:    
     print(ch)
