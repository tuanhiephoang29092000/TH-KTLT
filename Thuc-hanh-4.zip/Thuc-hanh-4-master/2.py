s=input(" Nhap chuoi: ")
for ch in s.split():
    print(ch)
